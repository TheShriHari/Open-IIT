"""Output files: one row per address, OUT addresses go to VERIFY_FIRST without a pin."""
import json

import pandas as pd
import pytest

from conftest import ROOT
from load import N_ADDRESSES

OUT = ROOT / "outputs"
PER_ADDRESS = ["pins_text_prior.csv", "pins_fused.csv", "pins_final.csv", "geocodes.csv",
               "planner_actions.csv", "ps2_location_confidence.csv"]


@pytest.mark.parametrize("name", PER_ADDRESS)
def test_one_row_per_address(name):
    df = pd.read_csv(OUT / name)
    assert len(df) == N_ADDRESSES == 3117
    assert df.address_id.is_unique


def test_offline_json_one_record_per_address():
    data = json.load(open(OUT / "geocodes_offline.json", encoding="utf-8"))
    ids = [r["address_id"] for rows in data.values() for r in rows]
    assert len(ids) == N_ADDRESSES and len(set(ids)) == N_ADDRESSES


def test_out_of_territory_is_verify_first():
    g = pd.read_csv(OUT / "geocodes.csv")
    out = g[g.town_id == "OUT"]
    assert len(out) == 237
    assert (out.action == "VERIFY_FIRST").all()
    assert out.pin_x.isna().all() and out.pin_y.isna().all()
