"""Step 1: load every CSV and join them into two master tables.

addr_df  - one row per address (3,117): text, town, lender format, split, baseline pin.
visit_df - one row per field visit (5,578): check-in, outcome, remark, photo, plus a
           summary of the GPS trail (duration, path length, straightness, trail end), and the
           visit position pos_x/pos_y: centroid of the trail's stationary tail (trailing steps
           < 15 m) when it has >= 2 points, else the check-in. checkin_x/y stay the raw check-in.

surveyed_addresses.csv (the answer key) is deliberately NOT loaded here.
Only evaluate.py reads it.
"""
from pathlib import Path

import numpy as np
import pandas as pd

DATA = Path(__file__).resolve().parent.parent / "data"
N_ADDRESSES = 3117
TAIL_MIN_POINTS = 2


def read(name: str) -> pd.DataFrame:
    return pd.read_csv(DATA / name)


def map_tables():
    """The static map: towns, localities and landmarks."""
    return read("towns.csv"), read("localities.csv"), read("landmarks_poi.csv")


def load_addresses() -> pd.DataFrame:
    addr = read("addresses.csv")
    acc = read("accounts.csv")[["account_id", "lender_id", "income_type", "preferred_language"]]
    lenders = read("lenders.csv")[["lender_id", "kyc_address_format"]]
    splits = read("splits.csv")
    base = read("baseline_geocodes.csv").rename(
        columns={"geocoder_x": "base_x", "geocoder_y": "base_y", "precision": "base_precision"}
    )
    df = (
        addr.merge(acc, on="account_id", how="left")
        .merge(lenders, on="lender_id", how="left")
        .merge(splits, on="account_id", how="left")
        .merge(base, on="address_id", how="left")
    )
    assert len(df) == len(addr), "join created duplicate address rows"
    return df


def summarise_trails() -> pd.DataFrame:
    """Squeeze each visit's GPS breadcrumb trail into a few numbers."""
    g = read("visit_gps_points.csv").sort_values(["visit_id", "seq"])
    g["ts"] = pd.to_datetime(g["point_ts"])
    g["step_m"] = np.hypot(g.groupby("visit_id").x.diff(), g.groupby("visit_id").y.diff()).fillna(0)
    agg = g.groupby("visit_id").agg(
        trail_points=("seq", "size"),
        trail_start=("ts", "min"),
        trail_end_ts=("ts", "max"),
        path_m=("step_m", "sum"),
        x0=("x", "first"),
        y0=("y", "first"),
        trail_end_x=("x", "last"),
        trail_end_y=("y", "last"),
    )
    agg["trail_minutes"] = (agg.trail_end_ts - agg.trail_start).dt.total_seconds() / 60
    direct = np.hypot(agg.trail_end_x - agg.x0, agg.trail_end_y - agg.y0)
    # 1.0 = rode straight to the spot, near 0 = wandered / searched
    agg["straightness"] = (direct / agg.path_m.clip(lower=1)).clip(upper=1)

    # time spent standing still at the end of the trail (steps < 15 m per ~30 s)
    def end_dwell(v):
        moving = (v.step_m.values >= 15)[::-1]
        still = np.argmax(moving) if moving.any() else len(moving)
        return still * 30

    agg["trail_end_still_s"] = g.groupby("visit_id")[["step_m"]].apply(end_dwell)

    # stationary tail: the trailing run of steps < 15 m, plus the point where that run starts
    moving = (g.step_m >= 15).astype(int)
    after_last_move = moving[::-1].groupby(g.visit_id[::-1]).cumsum()[::-1] == 0
    starts_run = after_last_move.groupby(g.visit_id).shift(-1, fill_value=False) & ~after_last_move
    tail = g[after_last_move | starts_run]
    agg = agg.join(tail.groupby("visit_id").agg(tail_n=("x", "size"), tail_x=("x", "mean"), tail_y=("y", "mean")))
    return agg.drop(columns=["trail_start", "trail_end_ts", "x0", "y0"]).reset_index()


def check_pins(pins: pd.DataFrame, name: str) -> None:
    """One row per address, every address present."""
    dup = pins.address_id[pins.address_id.duplicated()].unique()
    assert len(dup) == 0, f"{name}: {len(dup)} duplicate address_ids, e.g. {list(dup[:5])}"
    assert len(pins) == N_ADDRESSES, f"{name}: {len(pins)} rows, expected {N_ADDRESSES}"


def load_visits(addr_df: pd.DataFrame | None = None) -> pd.DataFrame:
    if addr_df is None:
        addr_df = load_addresses()
    v = read("field_visits.csv")
    v = v.merge(addr_df[["address_id", "town_id", "split"]], on="address_id", how="left")
    v = v.merge(summarise_trails(), on="visit_id", how="left")
    v["checkin_vs_trail_end_m"] = np.hypot(v.checkin_x - v.trail_end_x, v.checkin_y - v.trail_end_y)
    # visit position: centroid of the trail's stationary tail when it has >= 2 points, else check-in
    use_tail = v.tail_n.fillna(0) >= TAIL_MIN_POINTS
    v["pos_x"] = np.where(use_tail, v.tail_x, v.checkin_x)
    v["pos_y"] = np.where(use_tail, v.tail_y, v.checkin_y)
    v["pos_source"] = np.where(use_tail, "trail_tail", "checkin")
    return v


def sanity_report(addr: pd.DataFrame, visits: pd.DataFrame) -> dict:
    out = {
        "addresses": len(addr),
        "visits": len(visits),
        "visits_with_unknown_address": int(visits.town_id.isna().sum()),
        "visits_without_trail": int(visits.trail_points.isna().sum()),
        "addresses_without_baseline": int(addr.base_x.isna().sum()),
        "of_which_OUT": int((addr.base_x.isna() & (addr.town_id == "OUT")).sum()),
        "addresses_with_visits": int(addr.address_id.isin(visits.address_id).sum()),
        "split_accounts": addr.drop_duplicates("account_id").split.value_counts().to_dict(),
    }
    return out


if __name__ == "__main__":
    a = load_addresses()
    v = load_visits(a)
    for k, val in sanity_report(a, v).items():
        print(f"{k:30s} {val}")
